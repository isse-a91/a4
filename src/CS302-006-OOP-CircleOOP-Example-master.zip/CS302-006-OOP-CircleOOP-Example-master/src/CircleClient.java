/********************************************************************
 * Programmer:      sveinson
 * Class:           CS30S
 *
 * Assignment:      Intro to OOP Example
 *
 * Description:     instantiate several Circle objects and test out their
 *                  behaviours by invoking their methods
 ***********************************************************************/
 
 // import java libraries here as needed
 
 import javax.swing.*;
 //import java.text.DecimalFormat;
 import java.io.*;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Date;

public class CircleClient {  // begin class
    
    public static void main(String[] args)throws IOException {  // begin main
    
    // ********* declaration of constants **********
    
    // ********** declaration of variables **********

        String strin;		// string data input from keyboard
        String strout;		// processed info string to be output
        String bannerOut;		// string to print banner to message dialogs

        String prompt;		// prompt for use in input dialogs

        String delim = "[ :]+";	// delimiter string for splitting input string
        String[] tokens;                        // string array for gathering input
        
        String nl = System.lineSeparator();
        // new line character for file writing
        
        BufferedReader fin = null;
    	
    // ***** create objects *******
    
//        Circle circle1 = new Circle();
//        Circle circle2 = new Circle(4.5, 5, 7);
        
        ArrayList<Circle> circles = new ArrayList();
        
 // some code to introduce the basic functions of an array list
 
//          System.out.println("Circle 1 position: " + circle1.getPositions());
//          System.out.println("Circle 2 details: " + circle2.toString());
          
          // this won't work because position is private instanfe variable
          //System.out.println("Circle 1 position: " + circle1.position.getX());
//        System.out.println("circles length: " + circles.size());
//        Circle myCircle = new Circle(3);
//        circles.add(myCircle);
//        System.out.println("circles length: " + circles.size());
//        
//        System.out.println("Circle: " + circles.get(0).getArea());
//        
//        circles.add(new Circle(8));
        
        
    
        //DecimalFormat df1 = new DecimalFormat("##.###");
    
    // the ProgramInfo class has both a default and initialized constructor
    // so you can choose which model you want to employ
    
        ProgramInfo programInfo = new ProgramInfo();
        //ProgramInfo programInfo = new ProgramInfo("assignment name");
        
        try{
            fin = new BufferedReader(new FileReader("circleData.txt"));
        } // end try
        catch(IOException e){
            System.out.println("file not found");
        } // end catch 
        
        PrintWriter fout = new PrintWriter(new BufferedWriter(new FileWriter("CircleOutput.txt")));
    	
    // ********** Print output Banner **********

        System.out.println(programInfo.getBanner("A1Q2"));
        fout.println(programInfo.getBanner("A1Q2"));

        //System.out.println(programInfo.getBanner());
        //fout.println(programInfo.getBanner());
	    	
    // ************************ get input **********************

    // ************************ processing ***************************
   
        strin = fin.readLine();
        
        while(strin != null){
            //System.out.println(strin);
            tokens = strin.split(delim);
            circles.add(new Circle(Double.parseDouble(tokens[0]), tokens));
            
            strin = fin.readLine();
        } // end eof loop
        
//        System.out.println("circles length: " + circles.size());
//        System.out.println("circle 4: " + circles.get(3).toString());
//        
//        System.out.println("circle 2: " + circles.get(1).toString());
//        circles.get(1).setRadius(5.5);
//        System.out.println("circle 2: " + circles.get(0).toString());
        
        for(int i = 0; i < circles.size(); i++){
            System.out.println("circle " + i + ": " + circles.get(i).toString());
        } // end for
        
//        circles.remove(2);
//         System.out.println("circles length: " + circles.size());
//         
//        for(int i = 0; i < circles.size(); i++){
//            System.out.println("circle " + i + ": " + circles.get(i).toString());
//        } // end for
        
        


    // ************************ print output ****************************
    
        /*System.out.println(circle2.getRadius());
        System.out.format("Circle 1 area = %10.5f %s", circle1.getArea(), nl);
        System.out.format("Circle 2 area = %10.5f %s", circle2.getArea(), nl);
        */
//        System.out.println(circle2.toString() + nl + nl);
//        
//        circle2.setRadius(2.0);
//        System.out.println(circle2.toString() + nl + nl);
//        System.out.println(circle1.toString() + nl + nl);
//    
    
    // ******** closing message *********
        
        System.out.println(programInfo.getClosingMessage());
        fout.println(programInfo.getClosingMessage());
        
    // ***** close streams *****
        
        //fin.close();                // close input buffer stream
        fout.close();               // close output stream
        
    }  // end main
}  // end class
