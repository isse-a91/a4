/********************************************************************
 * Programmer:	sveinson
 * Class:       CS30S
 *
 * Assignment:  OOP Advanced example
 *
 * Description: a position object for the circle OOP project
 ***********************************************************************/

// import libraries as needed here

public class Position {
    //*** Class Variables ***
    
    //*** Instance Variables ***
    
    private int x = 0;          // x coordinate of object
    private int y = 0;          // y coordinate of object
    
    private String nl = System.lineSeparator();
    // new line character for file writing
    
    //*** Constructors ***
    /*****************************************
    * Description: initialized constructor
    * 
    * Interface:
    * 
    * @param        x: int the x coordinate of the object
    * @param        y: int the y coordinate of the object
    * ****************************************/
    public Position(int xCoord, int yCoord){
        this.x = xCoord;
        this.y = yCoord;
    } // end initialized constructor

 
    /*****************************************
    * Description: brief description of the methods purpose
    * 
    * Interface:
    * 
    * @param        each parameter of the method should be listed with an @param
    * @param        parametername description of parameter
    * 
    * @return       any return value will be noted here
    * ****************************************/
    
    
    //*** Getters ***
    
    /*****************************************
    * Description: get the y coordinate
    * 
    * Interface:
    * 
    * @return       int: the y coordinate
    * ****************************************/    
    public int getY() {
        return y;
    }
    
    /*****************************************
    * Description: return the x and y coordinates
    * 
    * Interface:
    * 
    * @return       String: the x and y coordinates
    * ****************************************/ 
    @Override
    public String toString() {
        String st = "";
        
        st = String.format("%4d, %4d%s", this.x, this.y, nl);
        
        return st;
    }

    /*****************************************
     * Description: get the x coordinate
     *
     * Interface:
     *
     * @return       int: the x coordinate
     * ****************************************/     
    public int getX() {
        return x;
    }
    
    //*** Setters ***
    
    /*****************************************
    * Description: move the object to a new location
    * 
    * Interface:
    * 
    * @param        x: int the new x coordinate
    * @param        y: int the new y coordinate
    * ****************************************/
    public void moveObject(int x, int y){
        setX(x);
        setY(y);
    } // end moveObject
    
    /*****************************************
    * Description: set the x coordinate
    * 
    * Interface:
    * 
    * @param        x: int the new x coordinate
    * ****************************************/
    public void setX(int x) {
        this.x = x;
    } 
    
    /*****************************************
    * Description: set the y coordinate
    * 
    * Interface:
    * 
    * @param        y: int the new x coordinate
    * ****************************************/    
    public void setY(int y) {
        this.y = y;
    }
} // end of public class
